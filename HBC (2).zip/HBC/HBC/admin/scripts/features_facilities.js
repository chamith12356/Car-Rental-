
let features_s_form = document.getElementById('features_s_form');
let facilities_s_form = document.getElementById('facilities_s_form');

features_s_form.addEventListener('submit', function(e) {
  e.preventDefault();
  add_features();
});

function add_features() {
  let data = new FormData();
  data.append('name', features_name_inp.value);
  data.append('add_features', '');

  let xhr = new XMLHttpRequest();
  xhr.open("POST", "ajax/features_facilities_crud.php", true);

  xhr.onload = function() {

    var myModal = document.getElementById('features-s');
    var modal = bootstrap.Modal.getInstance(myModal);
    modal.hide();
    console.log(this.responseText);
    if (this.responseText == 1) {
      alert('success', 'New Features Add!');
      features_name_inp.value = '';
      get_features();

    } else {
      alert('eroor', 'Sever Down!');
    }

  }


  xhr.send(data);
}

function get_features() {
  let xhr = new XMLHttpRequest();
  xhr.open("POST", "ajax/features_facilities_crud.php", true);
  xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

  xhr.onload = function() {
    document.getElementById('features-data').innerHTML = this.responseText;
  }

  xhr.send('get_features');
}

function rem_features(val) {
  let xhr = new XMLHttpRequest();
  xhr.open("POST", "ajax/features_facilities_crud.php", true);
  xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

  xhr.onload = function() {
    if (this.responseText == 1) {
      alert('success', 'Features removed!');
      get_features();
    } else {
      alert('eroor', 'Server Down!');
    }
  }

  xhr.send('rem_features=' + val);
}






facilities_s_form.addEventListener('submit', function(e) {
  e.preventDefault();
  add_facilities();
});

function add_facilities() {
  let data = new FormData();
  data.append('name', facilities_name_inp.value);
  data.append('icon', facilities_icon_inp.files[0]);
  data.append('desc', facilities_description_inp.value);

  data.append('add_facilities', '');

  let xhr = new XMLHttpRequest();
  xhr.open("POST", "ajax/features_facilities_crud.php", true);
  console.log(this.responseText);

  xhr.onload = function() {

    var myModal = document.getElementById('facilities-s');
    var modal = bootstrap.Modal.getInstance(myModal);
    modal.hide();
    if (this.responseText == 1) {
      alert('success', 'New Facilities Add!');
      features_name_inp.value = '';
      facilities_description_inp.value = '';
      facilities_icon_inp.files[0] = '';
      get_facilities();

    } else {
      alert('eroor', 'Sever Down!');
    }

  }


  xhr.send(data);
}

function get_facilities() {
  let xhr = new XMLHttpRequest();
  xhr.open("POST", "ajax/features_facilities_crud.php", true);
  xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

  xhr.onload = function() {
    document.getElementById('facilities-data').innerHTML = this.responseText;
  }

  xhr.send('get_facilities');
}


function rem_facilities(val) {
  let xhr = new XMLHttpRequest();
  xhr.open("POST", "ajax/features_facilities_crud.php", true);
  xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

  xhr.onload = function() {
    if (this.responseText == 1) {
      alert('success', 'Facilities removed!');
      get_features();
    } else {
      alert('eroor', 'Server Down!');
    }
  }

  xhr.send('rem_facilities=' + val);
}



window.onload = function() {
  get_features();
  get_facilities();
}