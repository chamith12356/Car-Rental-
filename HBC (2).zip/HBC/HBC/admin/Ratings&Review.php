<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Panel-Ratings & Review</title>
  <?php require('inc/links.php'); ?>


</head>

<body class="bg-light">
  <?php require('inc/header.php'); ?>

  <div class="container-fluid " id="main-content">
    <div class="row">
      <div class="col-lg-10 ms-auto p-4 overflow-hidden ">
        <h3 class="mb-4">Ratings & Review</h3>

<div class="text-end mb-4">

  <a href="?seen=all" class="btn btn-dark rounded-pill shadow-none btn-sm">Mark all read</a>
  <a href="?del=all" class="btn btn-danger rounded-pill shadow-none btn-sm">Delete all </a>
</div>



        <div class="table-responsive-md" style="height: 450px; overflow-y:scroll;">
          <table class="table table-hover border">
            <thead class="stcky-top">
              <tr class="bg-dark text-light">
                <th scope="col">#</th>
                <th scope="col">Car Name</th>
                <th scope="col">User Name</th>
                <th scope="col">Ratings</th>
                <th scope="col" style="width:30%">Review</th>
                <th scope="col">Date</th>
                <th scope="col">Action</th>

              </tr>
            </thead>
            <tbody>

            

            </tbody>
          </table>
        </div>


        <!-- CAROUSEL team -->
        <div class="card border-0 shadow-sm mb-4">
          <div class="card-body">

          </div>
        </div>


      </div>
    </div>
    <?php require('inc/scripts.php'); ?>
</body>

</html>