<?php
require('../admin/inc/db_config.php');
require('../admin/inc/essentials.php');
require("../inc/sendgrid/sendgrid-php.php");

function send_mail($email, $name, $token)
{
    $emailObj = new \SendGrid\Mail\Mail();
    $emailObj->setFrom("ushanloshitha@gmail.com", "UBC RENT A CAR");
    $emailObj->setSubject("Account Verification Link");

    $emailObj->addTo($email, $name);

    $emailObj->addContent(
        "text/html",
        "Click the link to confirm your email: <br>
         <a href='" . SITE_URL . "email_confirm.php?email_confirmation&email=$email&token=$token" . "'>Click Me</a>"
    );

    $sendgrid = new \SendGrid(SENDGRID_API_KEY);

    try {
        $response = $sendgrid->send($emailObj);

        if ($response->statusCode() == 202) {
            return true;
        } else {
            // Log the error or return a more detailed message
            error_log("SendGrid error: " . $response->body());
            return false;
        }
    } catch (Exception $e) {
        // Log the exception or return a more detailed message
        error_log("Exception in sending mail: " . $e->getMessage());
        return false;
    }
}

if (isset($_POST['register'])) {
    $data = filteration($_POST);

    // Validate input data (add more validation if needed)

    // match password and confirm password
    if ($data['pass'] != $data['cpass']) {
        echo 'pass_mismatch';
        //exit;
    }

    // check if user exists or not
    $u_exist = select("SELECT * FROM `user_cred` WHERE `email` = ? OR `phonenum` = ? LIMIT 1", [$data['email'], $data['phonenum']], "ss");

    if (mysqli_num_rows($u_exist) != 0) {
        $u_exist_fetch = mysqli_fetch_assoc($u_exist);
        echo ($u_exist_fetch['email'] == $data['email']) ? 'email_already' : 'phone_already';
        //exit;
    }

    // upload user image to the server
    $img = uploadUserImage($_FILES['profile']);

    if ($img == 'inv_img') {
        echo 'inv_img';
        //exit;
    } elseif ($img == 'upd_failed') {
        echo 'upd_failed';
        //exit;
    }

    // send confirmation link to the user's email
    $token = bin2hex(random_bytes(16));

    if (!send_mail($data['email'], $data['name'], $token)) {
        echo "mail_failed";
        //exit;
    }

    $enc_pass = password_hash($data['pass'], PASSWORD_BCRYPT);

    $query = "INSERT INTO `user_cred`(`name`, `email`, `address`, `phonenum`, `pincode`, `dob`, `profile`, `password`, `token`) VALUES (?,?,?,?,?,?,?,?,?)";

    $values = [$data['name'], $data['email'], $data['address'], $data['phonenum'], $data['pincode'], $data['dob'], $img, $enc_pass, $token];

    if (insert($query, $values, 'sssssssss')) {
        echo 1;
    } else {
        echo 'ins_failed';
    }
}
?>
