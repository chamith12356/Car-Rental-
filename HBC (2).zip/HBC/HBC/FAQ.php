<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <?php require('inc/links.php'); ?>
    <title><?php echo $settings_r['site_title'] ?> -FAQs</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">

<?php require('inc/header.php'); ?>

  

  <section class="container my-5">
    <h2 class="text-primary mb-4">General Questions</h2>
    <div class="bg-white p-4 rounded shadow mb-4">
      <h3 class="h5 mb-2">Question 1?</h3>
      <p>Answer to question 1.</p>
    </div>

    <div class="bg-white p-4 rounded shadow mb-4">
      <h3 class="h5 mb-2">Question 2?</h3>
      <p>Answer to question 2.</p>
    </div>
  </section>

  <section class="container my-5">
    <h2 class="text-primary mb-4">Payment and Billing</h2>
    <div class="bg-white p-4 rounded shadow mb-4">
      <h3 class="h5 mb-2">Question 3?</h3>
      <p>Answer to question 3.</p>
    </div>

    <div class="bg-white p-4 rounded shadow mb-4">
      <h3 class="h5 mb-2">Question 4?</h3>
      <p>Answer to question 4.</p>
    </div>
  </section>

  <!-- Add more sections for different categories if needed -->

  <?php require('inc/footer.php'); ?>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>